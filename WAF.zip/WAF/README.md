##Installation Instructions:

- Make the script runnable with `chmod +x install.sh`
- Execute `./install.sh` as **sudoer**
- Check the installation with `/usr/local/nginx/sbin/nginx -t`

#Nginx configuration:

- go to configuration file `/usr/local/nginx/conf/nginx.conf`
- Replace the variable <NOM_DU_SERVEUR_WEB> with Web server hostname/IP adress
- Replace the variable <IP_DE_InterfaceWeb> with the proxy target IP adress
- reload Nginx with `sudo systemctl restart nginx`

#ModSecurity Test:

- You can test if ModSecurity is working by using the following command:
  `curl -d "id=1 AND 1=1" http://yourserver.com/index.php`

If you get an 403 Forbidden response, ModSecurity is working !
