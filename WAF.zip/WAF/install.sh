#!/bin/bash

#Mise à jour du système
dnf update -y
dnf upgrade -y

#Installation des dépendances
yum groupinstall -y "Development Tools"
yum install -y git make httpd httpd-devel pcre pcre-devel libxml2 libxml2-devel curl curl-devel openssl openssl-devel

#Compilation du code source de ModSecurity
/usr/src
git clone -b nginx_refactoring https://github.com/SpiderLabs/ModSecurity.git
cd ModSecurity
sed -i '/AC_PROG_CC/a\AM_PROG_CC_C_O' configure.ac
sed -i '1 i\AUTOMAKE_OPTIONS = subdir-objects' Makefile.am
./autogen.sh
./configure --enable-standalone-module --disable-mlogc
make

#Compilation du code source Nginx
cd /usr/src
wget https://nginx.org/download/nginx-1.20.2.tar.gz
tar -zxvf nginx-1.20.2.tar.gz && rm -f nginx-1.20.2.tar.gz 
groupadd -r nginx
useradd -r -g nginx -s /sbin/nologin -M nginx
cd nginx-1.20.2/
./configure --user=nginx --group=nginx --add-module=/usr/src/ModSecurity/nginx/modsecurity --with-http_ssl_module
make
make install
sudo sed -i "s/#user  nobody;/user nginx nginx;/" /usr/local/nginx/conf/nginx.conf
#Test de linstallation
/usr/local/nginx/sbin/nginx -t

#Configuration Nginx et ModSecurity
cd /usr/local/nginx/conf/
rm -rf nginx.conf
curl "https://github.com/xNeroForte/Reseau-Linux/blob/main/Projet-Infra/nginx.conf" -o nginx.conf
cd /usr/local/nginx/conf/
curl "https://github.com/xNeroForte/Reseau-Linux/blob/main/Projet-Infra/modsec_includes.conf" -o modsec_includes.conf
cp /usr/src/ModSecurity/modsecurity.conf-recommended /usr/local/nginx/conf/modsecurity.conf
cp /usr/src/ModSecurity/unicode.mapping /usr/local/nginx/conf/
sed -i "s/SecRuleEngine DetectionOnly/SecRuleEngine On/" /usr/local/nginx/conf/modsecurity.conf
cd /usr/local/nginx/conf
git clone https://github.com/SpiderLabs/owasp-modsecurity-crs.git
cd owasp-modsecurity-crs
mv crs-setup.conf.example crs-setup.conf
cd rules
mv REQUEST-900-EXCLUSION-RULES-BEFORE-CRS.conf.example REQUEST-900-EXCLUSION-RULES-BEFORE-CRS.conf
mv RESPONSE-999-EXCLUSION-RULES-AFTER-CRS.conf.example RESPONSE-999-EXCLUSION-RULES-AFTER-CRS.conf