using System;
/*
namespace GameNetServer {
    public class Program {
        public static void Main(string[] args) {
            Game.GameBegin();
        }
    }
}
*/